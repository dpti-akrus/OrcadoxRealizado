import { TABELAS } from "../constants/database.js";
import {
  atualizarDados,
  buscarDados,
  executarTransacao,
  excluirDados,
  inserirDados,
  consultaNativaDisponivel,
  executarConsultaSankhya,
  executarSalvamentoSankhya
} from "./sankhya/nativeSqlService.js";
import { criarFiltros, filtroIgual, somenteDados } from "./serviceHelpers.js";

export async function buscarUsuariosSistema({ termo, ativos = true } = {}) {
  const filtros = [];
  if (ativos) filtros.push(filtroIgual("ATIVO", "S"));
  if (termo) filtros.push({ campo: "NOMEUSU", operador: "contains", valor: termo });
  return buscarDados({
    tabela: TABELAS.USUARIO,
    campos: ["CODUSU", "NOMEUSU", "ATIVO"],
    filtros,
    ordenacao: [{ campo: "NOMEUSU", direcao: "asc" }]
  });
}

export async function buscarUsuarioSistemaPorCodigo(codigoUsuario) {
  const codigo = Number(codigoUsuario);
  if (!Number.isInteger(codigo) || codigo < 0) {
    throw new Error("Informe um código de usuário válido.");
  }

  if (consultaNativaDisponivel()) {
    const registros = await executarConsultaSankhya(
      "SELECT CODUSU, NOMEUSUCPLT, NOMEUSU FROM TSIUSU WHERE CODUSU = ?",
      [{ value: codigo, type: "I" }]
    );
    const usuario = registros[0];
    if (!usuario) return null;

    return {
      codigo: usuario.CODUSU,
      nome: String(usuario.NOMEUSUCPLT || usuario.NOMEUSU || "").trim()
    };
  }

  const resultado = await buscarDados({
    tabela: TABELAS.USUARIO,
    campos: ["CODUSU", "NOMEUSUCPLT", "NOMEUSU"],
    filtros: [filtroIgual("CODUSU", codigo)]
  });
  const usuario = somenteDados(resultado)[0];
  if (!usuario) return null;

  return {
    codigo: usuario.CODUSU,
    nome: String(usuario.NOMEUSUCPLT || usuario.NOMEUSU || "").trim()
  };
}

export async function buscarUsuarios(filtros = {}) {
  if (consultaNativaDisponivel()) {
    const condicoes = [];
    const parametros = [];
    if (filtros.codigoUsuario !== undefined && filtros.codigoUsuario !== null && filtros.codigoUsuario !== "") {
      const codigo = Number(filtros.codigoUsuario);
      if (!Number.isInteger(codigo)) throw new Error("Código de usuário inválido.");
      condicoes.push("CODUSU = ?");
      parametros.push({ value: codigo, type: "I" });
    }
    if (filtros.ativo) {
      condicoes.push("ATIVO = ?");
      parametros.push({ value: filtros.ativo === "S" ? "S" : "N", type: "S" });
    }
    const where = condicoes.length ? ` WHERE ${condicoes.join(" AND ")}` : "";
    const dados = await executarConsultaSankhya(
      `SELECT IDORCUSU, CODUSU, NOMEAPP, CARGO, TIPOUSU, ATIVO FROM AD_ORCUSU${where} ORDER BY NOMEAPP`,
      parametros
    );
    return { dados, total: dados.length };
  }

  const resultado = await buscarDados({
    tabela: TABELAS.ORC_USUARIO,
    campos: ["IDORCUSU", "CODUSU", "NOMEAPP", "CARGO", "TIPOUSU", "ATIVO"],
    filtros: criarFiltros({ CODUSU: filtros.codigoUsuario, ATIVO: filtros.ativo }),
    ordenacao: [{ campo: "NOMEAPP", direcao: "asc" }]
  });

  if (!filtros.incluirCentros || !resultado.dados.length) return resultado;
  const ids = resultado.dados.map((usuario) => usuario.IDORCUSU);
  const vinculos = somenteDados(await buscarDados({
    tabela: TABELAS.ORC_USUARIO_CENTRO,
    campos: ["IDORCUSUCUS", "IDORCUSU", "IDORCCUS", "ATIVO"],
    filtros: [{ campo: "IDORCUSU", operador: "in", valor: ids }]
  }));

  return {
    ...resultado,
    dados: resultado.dados.map((usuario) => ({
      ...usuario,
      centros: vinculos.filter((vinculo) => vinculo.IDORCUSU === usuario.IDORCUSU)
    }))
  };
}

export async function salvarUsuario(dados, idsCentros = []) {
  const codigoUsuario = Number(dados.CODUSU);
  if (!Number.isInteger(codigoUsuario) || codigoUsuario < 0 || !dados.NOMEAPP?.trim() || !["N", "A", "D"].includes(dados.TIPOUSU)) {
    throw new Error("Usuário, nome e tipo de usuário válido são obrigatórios.");
  }

  const usuarioSistema = await buscarUsuarioSistemaPorCodigo(codigoUsuario);
  if (!usuarioSistema) {
    throw new Error("O código informado não existe na TSIUSU.");
  }

  const consulta = await buscarUsuarios({ codigoUsuario });
  const existente = consulta.dados[0];
  if (existente && Number(dados.IDORCUSU) !== Number(existente.IDORCUSU)) {
    throw new Error("Este usuário já está cadastrado na AD_ORCUSU.");
  }

  const dadosUsuario = {
    CODUSU: codigoUsuario,
    NOMEAPP: dados.NOMEAPP.trim(),
    CARGO: String(dados.CARGO || "").trim(),
    TIPOUSU: dados.TIPOUSU,
    ATIVO: dados.ATIVO ?? "S"
  };

  if (consultaNativaDisponivel()) {
    await executarSalvamentoSankhya(
      dadosUsuario,
      TABELAS.ORC_USUARIO,
      existente ? { IDORCUSU: existente.IDORCUSU } : undefined
    );
    return buscarUsuarios({ codigoUsuario });
  }

  return executarTransacao(async () => {
    let idUsuario = existente?.IDORCUSU;
    if (existente) {
      await atualizarDados({
        tabela: TABELAS.ORC_USUARIO,
        dados: dadosUsuario,
        filtros: [filtroIgual("IDORCUSU", idUsuario)]
      });
      await excluirDados({
        tabela: TABELAS.ORC_USUARIO_CENTRO,
        filtros: [filtroIgual("IDORCUSU", idUsuario)]
      });
    } else {
      const inserido = await inserirDados({
        tabela: TABELAS.ORC_USUARIO,
        dados: dadosUsuario
      });
      idUsuario = inserido.IDORCUSU;
      if (idUsuario === undefined || idUsuario === null) {
        throw new Error("A inclusão do usuário não retornou o campo IDORCUSU.");
      }
    }

    for (const idCentro of [...new Set(idsCentros)]) {
      await inserirDados({
        tabela: TABELAS.ORC_USUARIO_CENTRO,
        dados: { IDORCUSU: idUsuario, IDORCCUS: idCentro, ATIVO: "S" }
      });
    }
    return buscarUsuarios({ codigoUsuario: dados.CODUSU, incluirCentros: true });
  });
}

export async function alterarStatusUsuario(idUsuario, ativo) {
  return atualizarDados({
    tabela: TABELAS.ORC_USUARIO,
    dados: { ATIVO: ativo ? "S" : "N" },
    filtros: [filtroIgual("IDORCUSU", idUsuario)]
  });
}
