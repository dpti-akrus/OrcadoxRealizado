import { removerCamposVazios } from "../../helpers/objectHelpers.js";
import { criarAdaptadorMemoria } from "./memoryDataAdapter.js";

const IDENTIFICADOR_SEGURO = /^[A-Z][A-Z0-9_]*$/;
let adaptador = criarAdaptadorMemoria();

function validarIdentificador(valor, tipo) {
  if (!IDENTIFICADOR_SEGURO.test(valor)) throw new Error(`${tipo} inválido: ${valor}`);
}

function validarConfiguracao({ tabela, campos = [], filtros = [], periodo, ordenacao = [] }) {
  validarIdentificador(tabela, "Tabela");
  campos.forEach((campo) => validarIdentificador(campo, "Campo"));
  filtros.forEach(({ campo }) => validarIdentificador(campo, "Campo de filtro"));
  ordenacao.forEach(({ campo }) => validarIdentificador(campo, "Campo de ordenação"));
  if (periodo?.campo) validarIdentificador(periodo.campo, "Campo de período");
}

export function configurarAdaptadorDados(novoAdaptador) {
  const metodos = ["buscar", "inserir", "atualizar", "excluir", "transacao"];
  if (!novoAdaptador || metodos.some((metodo) => typeof novoAdaptador[metodo] !== "function")) {
    throw new Error(`Adaptador inválido. Implemente: ${metodos.join(", ")}.`);
  }
  adaptador = novoAdaptador;
}

export function obterAdaptadorDados() {
  return adaptador;
}

function obterContextosSankhya() {
  const contextos = [globalThis];

  try {
    if (globalThis.parent && globalThis.parent !== globalThis) contextos.push(globalThis.parent);
  } catch {}

  try {
    if (globalThis.top && !contextos.includes(globalThis.top)) contextos.push(globalThis.top);
  } catch {}

  return contextos;
}

function obterExecuteQuery() {
  for (const contexto of obterContextosSankhya()) {
    try {
      if (typeof contexto?.executeQuery === "function") {
        return { contexto, executar: contexto.executeQuery };
      }
    } catch {}
  }
  return null;
}

function obterJxSankhya() {
  for (const contexto of obterContextosSankhya()) {
    try {
      if (contexto?.JX) return contexto.JX;
    } catch {}
  }
  return null;
}

export function consultaNativaDisponivel() {
  return Boolean(obterExecuteQuery());
}

export async function executarConsultaSankhya(sql, parametros = []) {
  const consulta = obterExecuteQuery();
  if (!consulta) throw new Error("A função executeQuery não está disponível neste ambiente Sankhya.");

  return new Promise((resolve, reject) => {
    consulta.executar.call(
      consulta.contexto,
      sql,
      parametros,
      (value) => {
        try {
          const dados = typeof value === "string" ? JSON.parse(value) : value;
          resolve(Array.isArray(dados) ? dados : []);
        } catch (error) {
          reject(new Error("O Sankhya retornou uma resposta de consulta inválida."));
        }
      },
      (value) => {
        console.error("Erro ao executar consulta no Sankhya:", value);
        reject(new Error(typeof value === "string" ? value : "Não foi possível consultar os dados no Sankhya."));
      }
    );
  });
}

export async function executarSalvamentoSankhya(dados, instancia, chavesPrimarias) {
  const jx = obterJxSankhya();
  if (typeof jx?.salvar !== "function") {
    throw new Error("A função JX.salvar não está disponível neste ambiente Sankhya.");
  }

  try {
    return await jx.salvar.call(jx, dados, instancia, chavesPrimarias);
  } catch (error) {
    console.error(`Erro ao salvar registro na instância ${instancia}:`, error);
    throw new Error(error?.message || `Não foi possível salvar o registro em ${instancia}.`);
  }
}

export async function buscarDados(configuracao) {
  validarConfiguracao(configuracao);
  return adaptador.buscar(configuracao);
}

export async function inserirDados({ tabela, dados }) {
  validarConfiguracao({ tabela });
  const dadosLimpos = removerCamposVazios(dados);
  if (!Object.keys(dadosLimpos).length) throw new Error("Nenhum dado informado para inserção.");
  return adaptador.inserir({ tabela, dados: dadosLimpos });
}

export async function atualizarDados({ tabela, dados, filtros }) {
  validarConfiguracao({ tabela, filtros });
  if (!filtros?.length) throw new Error("Atualizações exigem ao menos um filtro.");
  const dadosLimpos = removerCamposVazios(dados);
  if (!Object.keys(dadosLimpos).length) throw new Error("Nenhum dado informado para atualização.");
  return adaptador.atualizar({ tabela, dados: dadosLimpos, filtros });
}

export async function excluirDados({ tabela, filtros }) {
  validarConfiguracao({ tabela, filtros });
  if (!filtros?.length) throw new Error("Exclusões exigem ao menos um filtro.");
  return adaptador.excluir({ tabela, filtros });
}

export async function executarTransacao(operacao) {
  return adaptador.transacao(operacao);
}
